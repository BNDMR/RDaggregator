# Check initial versions (internal)
test_that("finds internal pack versions", {
  # include getOption verification
  df_versions = get_pack_versions()
  expect_equal(df_versions %>% ncol(), 3)
  expect_true('internal' %in% df_versions$location)
})

# Test adding new pack
test_that("adds a new pack nomenclature", {
  usr_dir = tools::R_user_dir('orphatools', 'config')
  versions_path = file.path(usr_dir, 'pack_versions.csv')
  if(file.exists(versions_path))
    file.remove(versions_path)
  pack_zipfile = test_path('fixtures', 'Orphanet_Nomenclature_Pack_FR_short.zip')
  expect_error(add_nomenclature_pack('inexisting.file'), 'not found')
  # expect_error(add_nomenclature_pack('corrupt_zip'))
  # expect_snapshot(add_nomenclature_pack(pack_zipfile))
  expect_message(out <- add_nomenclature_pack(pack_zipfile), 'Loading and processing') %>%
    expect_message('Adding new') %>%
    expect_message('succesfully added')
  expect_true(out)

  df_versions = get_pack_versions()
  expect_equal(ncol(df_versions), 3)
  expect_gte(nrow(df_versions), 2)
})

# Test adding existing pack
test_that("adds existing nomenclature", {
  pack_zipfile = test_path('fixtures', 'Orphanet_Nomenclature_Pack_EN.zip')
  # force = FALSE
  expect_message(add_nomenclature_pack(pack_zipfile), 'Loading and processing') %>%
    expect_error('already exists')
  expect_equal(get_pack_versions() %>% dim(), c(2,3))
  # what if force = TRUE for this one (see distinct in data-pack.R)

  pack_zipfile = test_path('fixtures', 'Orphanet_Nomenclature_Pack_FR_short.zip')
  # force = TRUE
  expect_message(out <- add_nomenclature_pack(pack_zipfile, force=TRUE), 'Loading and processing') %>%
    expect_warning('replaced') %>%
    expect_message('succesfully added')
  expect_true(out)
  expect_equal(get_pack_versions() %>% dim(), c(2,3))
})

# Test adding default
test_that("set default correctly", {
  expect_equal(get_pack_versions() %>% filter(default) %>% pull(location), 'internal')

  pack_zipfile = test_path('fixtures', 'Orphanet_Nomenclature_Pack_FR_short.zip')
  # force = TRUE
  expect_message(out <- add_nomenclature_pack(pack_zipfile, force=TRUE, default=TRUE), 'Loading and processing') %>%
    expect_warning('replaced') %>%
    expect_message('succesfully added')
  expect_true(out)

  expect_equal(get_pack_versions() %>% dim(), c(2,3))
  expect_true(get_pack_versions() %>% filter(default) %>% pull(location) %>% str_ends('.rda'))

  # Roll back to old default
  set_default_pack_version(get_pack_versions() %>% filter(location=='internal') %>% pull(version))
})
