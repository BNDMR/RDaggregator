## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=6, fig.height=4
)

## ----include=FALSE------------------------------------------------------------
suppressWarnings(suppressPackageStartupMessages(library(kableExtra)))
suppressWarnings(suppressPackageStartupMessages(library(dplyr)))

## ----install------------------------------------------------------------------


## ----load_library-------------------------------------------------------------
library(orphatools)

## ----options, eval=F----------------------------------------------------------
#  orphatools_options()

## ----load---------------------------------------------------------------------
# Data from the nomenclature pack
df_nomenclature = load_raw_nomenclature()
classif_data = load_classifications()
df_synonyms = load_synonyms()
df_redirections = load_raw_redirections()

# Accessibility: Translate Orphanet concepts using internal dictionary
df_nomenclature = load_nomenclature()
df_redirections = load_redirections()

# Data from the associated genes file
df_associated_genes = load_associated_genes()
df_genes_synonyms = load_genes_synonyms()

## ----code_props, results='hold'-----------------------------------------------
orpha_code = 303
get_label(orpha_code)
get_classification_level(orpha_code)
get_status(orpha_code)
get_type(orpha_code)

## ----gen-basics---------------------------------------------------------------
orpha_code = 303
get_parents(orpha_code)
get_children(orpha_code)
get_ancestors(orpha_code)
get_descendants(orpha_code)
get_siblings(orpha_code)

## -----------------------------------------------------------------------------
df_parents = get_parents(orpha_code, output='edgelist')
graph_descendants = get_descendants(orpha_code, output='graph')

## ----lca----------------------------------------------------------------------
orpha_codes = c('303', '305', '595356')
get_LCAs(orpha_codes)
get_LCAs(orpha_codes, df_classif=classif_data[['ORPHAclassification_187_rare_skin_diseases_fr_2023']])

## ----merge_branches, results='hold'-------------------------------------------
orpha_codes = c('303', '305', '595356')
graph_family = merge_branches(orpha_codes, output = 'graph') # both
graph_family = merge_branches(orpha_codes, output = 'graph', direction = c('up', 'down')) # both
graph_family = merge_branches(orpha_codes, output = 'graph', direction = 'both') # both
plot(graph_family, layout=layout_tree)

graph_family = merge_branches(orpha_codes, output = 'graph', direction='up')
plot(graph_family, layout=layout_tree)

graph_family = merge_branches(orpha_codes, output = 'graph', direction='down')
plot(graph_family, layout=layout_tree)

## ----complete_family, results='hold'------------------------------------------
orpha_codes = c('79400', '79401', '79410')
graph_family = complete_family(orpha_codes, output = 'graph', max_depth=0)
graph_family = complete_family(orpha_codes, output = 'graph', max_depth=1)

## ----rolling_up, results='hold'-----------------------------------------------
subtype_to_disorder(orpha_code = '158676') # 158676 is a subtype of disorder
subtype_to_disorder(orpha_code = '303') # 303 is a group of disorder
get_lowest_groups(orpha_code = '158676')

## ----class--------------------------------------------------------------------
all_classif = load_classifications()
cat(sprintf('%s\n', names(all_classif)))

## ----use_spec_class, eval=FALSE-----------------------------------------------
#  orpha_code = 303
#  orpha_codes = c('79400', '79401', '79410')
#  get_ancestors(orpha_code, df_classif=classif_data[['ORPHAclassification_156_rare_genetic_diseases_fr_2023']])
#  get_ancestors(orpha_code, df_classif=classif_data[['ORPHAclassification_146_rare_cardiac_diseases_fr_2023']])
#  get_siblings(orpha_code, df_classif=classif_data[['ORPHAclassification_156_rare_genetic_diseases_fr_2023']])
#  get_siblings(orpha_code, df_classif=classif_data[['ORPHAclassification_187_rare_skin_diseases_fr_2023']])
#  complete_family(orpha_codes, df_classif=classif_data[['ORPHAclassification_187_rare_skin_diseases_fr_2023']])

## ----basic_plot, results='hold'-----------------------------------------------
orpha_code = 303
graph = get_ancestors(orpha_code, output='graph')

plot(graph)
plot(graph, layout=igraph::layout_as_tree)
plot(graph, layout=orphatools::layout_tree)

## ----interactive_plot, eval=F-------------------------------------------------
#  interactive_plot(graph_ancestors)

## ----color_plot---------------------------------------------------------------
init_codes = c(303, 305)
graph = merge_branches(init_codes, direction='down', output='graph') %>%
  color_codes(init_codes) %>%
  color_class_levels()
plot(graph)

## ----indent-------------------------------------------------------------------
orpha_codes = c(303, get_descendants('303'))

df = data.frame(orpha_code=orpha_codes) %>%
  orpha_df(orpha_code_col='orpha_code') %>%
  left_join(load_nomenclature(), by='orpha_code')

df_indent = apply_orpha_indent(df, indented_cols='label', prefix='Label_')
kable(df_indent, 'html')

## ----counting1----------------------------------------------------------------
df_patients = data.frame(patient_id = c(1,1,2,3,4,5,6),
                         code = c('303', '158673', '595356', '305', '79406', '79406', '595356'),
                         status = factor(c('ongoing', 'confirmed', 'ongoing', 'ongoing', 'confirmed', 'ongoing', 'ongoing'), levels=c('ongoing', 'confirmed'), ordered=TRUE))
kable(df_patients, 'html')

## -----------------------------------------------------------------------------
df_counts = df_patients %>% group_by(code) %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting2----------------------------------------------------------------
df_counts = df_patients %>% orpha_df(orpha_code_col = 'code') %>% group_by(code) %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting3----------------------------------------------------------------
df_counts = df_patients %>% orpha_df(orpha_code_col = 'code') %>% group_by(code) %>% summarize(n = n_distinct(patient_id)) %>% as.data.frame()
kable(df_counts, 'html')

## ----counting-mutate1---------------------------------------------------------
# Naive
df_patients_extended = df_patients %>% group_by(code) %>% mutate(n_included = n_distinct(patient_id)) %>% as.data.frame()
kable(df_patients_extended, 'html')

## ----counting-mutate2---------------------------------------------------------
# Turn on Orphanet mode
df_patients_extended_orpha = df_patients %>% orpha_df(orpha_code_col = 'code') %>% group_by(code) %>% mutate(n_included = n_distinct(patient_id)) %>% as.data.frame()
kable(df_patients_extended_orpha, 'html')

## ----rolling_up_codes---------------------------------------------------------
df_nomenclature = load_nomenclature() %>% select(orpha_code, level)
df_counts = df_patients %>%
  orpha_df(orpha_code_col = 'code') %>%
  group_by(code) %>%
  summarize(n = n_distinct(patient_id)) %>%
  left_join(df_nomenclature, by=c('code'='orpha_code')) %>%
  filter(level == 'Disorder') %>%
  as.data.frame()
kable(df_counts, 'html')

## ----group_other_vars---------------------------------------------------------
df_nomenclature = load_nomenclature() %>% select(orpha_code, level)
df_status = df_patients %>%
  orpha_df(orpha_code_col = 'code') %>%
  group_by(patient_id, code) %>%
  summarize(status = max(status)) %>%
  left_join(df_nomenclature, by=c('code'='orpha_code'))
kable(df_status, 'html')

## -----------------------------------------------------------------------------
df_nomenclature = load_nomenclature() %>% select(orpha_code, level)
df_counts = df_patients %>%
  orpha_df(orpha_code_col = 'code', force_codes = 231568) %>%
  group_by(code) %>%
  summarize(n = n_distinct(patient_id)) %>%
  left_join(df_nomenclature, by=c('code'='orpha_code')) %>%
  filter(level == 'Disorder') %>%
  as.data.frame()
kable(df_counts, 'html')

## ----code_redirection---------------------------------------------------------
orpha_codes = c(304, 166068, 166457)
redirect_code(orpha_codes)
redirect_code(orpha_codes, deprecated_only = TRUE)

## ----code_specification-------------------------------------------------------
orpha_code_cmt1 = 65753
orpha_code_cmtX = 64747

# Specification possible
specify_code(orpha_code_cmt1, 'MPZ', mode='symbol') # CMT1B is the lonely ORPHAcode both associated with CMT1 and MPZ
specify_code(orpha_code_cmt1, c('MPZ', 'POMT1'), mode='symbol') # POMT1 doesn't bring ambiguity

# Specification impossible
specify_code(orpha_code_cmtX, 'MPZ', mode='symbol') # No ORPHAcode is associated both to CMTX and MPZ
specify_code(orpha_code_cmt1, 'PMP22', mode='symbol') # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)
specify_code(orpha_code_cmt1, c('MPZ', 'PMP22'), mode='symbol') # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)

